package com.tiruneh.phonelog

import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

class NotifService : NotificationListenerService() {
    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (sbn.packageName == packageName) return
        if (sbn.notification.flags and Notification.FLAG_GROUP_SUMMARY != 0) return
        try {
            val db = Db(this)
            db.saveNotif(sbn.postTime, sbn.packageName)
            val name = try { packageManager.getApplicationLabel(packageManager.getApplicationInfo(sbn.packageName, 0)).toString() } catch (e: Exception) { sbn.packageName }
            db.saveApp(sbn.packageName, name)
        } catch (_: Exception) {}
    }
}
