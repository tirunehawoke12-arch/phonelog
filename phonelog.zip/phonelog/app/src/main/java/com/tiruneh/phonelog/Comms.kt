package com.tiruneh.phonelog

import android.content.Context
import android.provider.CallLog
import android.provider.Telephony
import org.json.JSONArray
import org.json.JSONObject

object Comms {
    /** ጥሪዎች፣ SMS (ከላኪ/ተቀባይ እና ጽሑፍ ጋር - ከስልኩ በቀጥታ ይነበባል፣ አይገለበጥም) እና ማሳወቂያዎች */
    fun json(ctx: Context, from: Long, to: Long): String {
        val args = arrayOf(from.toString(), to.toString())
        val calls = JSONArray(); val sms = JSONArray()
        try {
            ctx.contentResolver.query(CallLog.Calls.CONTENT_URI,
                arrayOf(CallLog.Calls.DATE, CallLog.Calls.TYPE, CallLog.Calls.DURATION),
                "date >= ? AND date < ?", args, null)?.use { c ->
                while (c.moveToNext()) calls.put(JSONObject().put("t", c.getLong(0)).put("type", c.getInt(1)).put("dur", c.getLong(2)))
            }
        } catch (_: SecurityException) {}
        try {
            ctx.contentResolver.query(Telephony.Sms.CONTENT_URI,
                arrayOf(Telephony.Sms.DATE, Telephony.Sms.TYPE, Telephony.Sms.ADDRESS, Telephony.Sms.BODY),
                "date >= ? AND date < ?", args, "date DESC")?.use { c ->
                while (c.moveToNext()) sms.put(JSONObject().put("t", c.getLong(0)).put("type", c.getInt(1)).put("a", c.getString(2) ?: "").put("b", c.getString(3) ?: ""))
            }
        } catch (_: SecurityException) {}
        return JSONObject().put("calls", calls).put("sms", sms).put("notifs", Db(ctx).notifsJson(from, to)).toString()
    }
}
