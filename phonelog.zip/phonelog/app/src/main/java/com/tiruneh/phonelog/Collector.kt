package com.tiruneh.phonelog

import android.app.AppOpsManager
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Process

object Collector {
    private const val DAY = 86_400_000L
    const val SCREEN = "__screenon"

    fun hasPermission(ctx: Context): Boolean {
        val ops = ctx.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        val mode = if (Build.VERSION.SDK_INT >= 29)
            ops.unsafeCheckOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), ctx.packageName)
        else
            @Suppress("DEPRECATION") ops.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), ctx.packageName)
        return mode == AppOpsManager.MODE_ALLOWED
    }

    @Synchronized
    fun collect(ctx: Context) {
        if (!hasPermission(ctx)) return
        val usm = ctx.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        val db = Db(ctx)
        val prefs = ctx.getSharedPreferences("phonelog", Context.MODE_PRIVATE)
        val now = System.currentTimeMillis()
        val from = maxOf(prefs.getLong("last", now - 6 * DAY) - 60_000, now - 7 * DAY)

        val events = usm.queryEvents(from, now)
        val e = UsageEvents.Event()
        val open = HashMap<String, Long>()
        val done = ArrayList<Triple<Long, Long, String>>() // start, end, pkg
        val lastIdx = HashMap<String, Int>()
        var lastScreen = 0L

        fun close(pkg: String, start: Long, end: Long) {
            if (end - start < 1000) return
            val i = lastIdx[pkg]
            if (i != null && start - done[i].second <= 5000) { // same app, short gap: merge
                done[i] = Triple(done[i].first, end, pkg)
            } else {
                done.add(Triple(start, end, pkg)); lastIdx[pkg] = done.size - 1
            }
        }

        while (events.hasNextEvent()) {
            events.getNextEvent(e)
            val pkg = e.packageName ?: continue
            val t = e.timeStamp
            when (e.eventType) {
                UsageEvents.Event.ACTIVITY_RESUMED -> if (!open.containsKey(pkg)) open[pkg] = t
                UsageEvents.Event.ACTIVITY_PAUSED ->
                    open.remove(pkg)?.let { close(pkg, it, t) }
                UsageEvents.Event.SCREEN_NON_INTERACTIVE, 26 /* DEVICE_SHUTDOWN */ -> {
                    for ((p, st) in open.toMap()) close(p, st, t)
                    open.clear()
                }
                UsageEvents.Event.SCREEN_INTERACTIVE -> {
                    if (t - lastScreen > 3000) done.add(Triple(t, t, SCREEN))
                    lastScreen = t
                }
            }
        }

        val pm = ctx.packageManager
        val skip = HashSet<String>().apply {
            add("com.android.systemui")
            try {
                pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME), 0)
                    .forEach { add(it.activityInfo.packageName) }
            } catch (_: Exception) {}
        }
        val known = HashSet<String>()
        db.writableDatabase.beginTransaction()
        try {
            for ((s, en, pkg) in done) {
                if (pkg in skip) continue
                db.saveSession(s, en, pkg)
                if (pkg != SCREEN && known.add(pkg)) {
                    val name = try { pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString() } catch (x: Exception) { pkg }
                    db.saveApp(pkg, name)
                }
            }
            db.writableDatabase.setTransactionSuccessful()
        } finally {
            db.writableDatabase.endTransaction()
        }
        prefs.edit().putLong("last", open.values.minOrNull() ?: now).apply()
    }
}
