package com.tiruneh.phonelog

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.provider.Settings
import android.webkit.JavascriptInterface
import android.webkit.WebView
import androidx.core.app.NotificationManagerCompat
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import java.util.concurrent.TimeUnit

class MainActivity : Activity() {
    private lateinit var web: WebView

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.addJavascriptInterface(Bridge(), "Android")
        setContentView(web)
        web.loadUrl("file:///android_asset/index.html")

        // በየ15 ደቂቃው በራሱ መረጃ ይሰበስባል (መተግበሪያው ባይከፈትም)
        val req = PeriodicWorkRequestBuilder<CollectWorker>(15, TimeUnit.MINUTES).build()
        WorkManager.getInstance(this).enqueueUniquePeriodicWork("collect", ExistingPeriodicWorkPolicy.KEEP, req)
    }

    override fun onResume() {
        super.onResume()
        Thread {
            try { Collector.collect(this) } catch (_: Exception) {}
            runOnUiThread { web.evaluateJavascript("window.onNativeResume && onNativeResume()", null) }
        }.start()
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, res: IntArray) {
        super.onRequestPermissionsResult(code, perms, res)
        web.evaluateJavascript("window.onNativeResume && onNativeResume()", null)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() { if (web.canGoBack()) web.goBack() else super.onBackPressed() }

    inner class Bridge {
        @JavascriptInterface fun hasPermission(): Boolean = Collector.hasPermission(this@MainActivity)
        @JavascriptInterface fun openSettings() {
            startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
        @JavascriptInterface fun getSessions(from: String, to: String): String =
            Db(this@MainActivity).sessionsJson(from.toLong(), to.toLong())
        @JavascriptInterface fun hasComms(): Boolean =
            checkSelfPermission(Manifest.permission.READ_CALL_LOG) == PackageManager.PERMISSION_GRANTED &&
                checkSelfPermission(Manifest.permission.READ_SMS) == PackageManager.PERMISSION_GRANTED
        @JavascriptInterface fun requestComms() {
            runOnUiThread { requestPermissions(arrayOf(Manifest.permission.READ_CALL_LOG, Manifest.permission.READ_SMS), 1) }
        }
        @JavascriptInterface fun hasNotifAccess(): Boolean =
            NotificationManagerCompat.getEnabledListenerPackages(this@MainActivity).contains(packageName)
        @JavascriptInterface fun openNotifSettings() {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
        @JavascriptInterface fun getComms(from: String, to: String): String =
            Comms.json(this@MainActivity, from.toLong(), to.toLong())
        @JavascriptInterface fun shareText(text: String) {
            val i = Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, text)
            startActivity(Intent.createChooser(i, "ሪፖርት አጋራ"))
        }
    }
}
