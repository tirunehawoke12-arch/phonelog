package com.tiruneh.phonelog

import android.content.Context
import androidx.work.Worker
import androidx.work.WorkerParameters

class CollectWorker(ctx: Context, params: WorkerParameters) : Worker(ctx, params) {
    override fun doWork(): Result {
        try { Collector.collect(applicationContext) } catch (_: Exception) {}
        return Result.success()
    }
}
