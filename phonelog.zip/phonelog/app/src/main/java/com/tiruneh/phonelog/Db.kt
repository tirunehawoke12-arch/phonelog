package com.tiruneh.phonelog

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import org.json.JSONArray
import org.json.JSONObject

class Db(ctx: Context) : SQLiteOpenHelper(ctx, "phonelog.db", null, 2) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE sessions(s INTEGER, e INTEGER, pkg TEXT, PRIMARY KEY(s, pkg))")
        db.execSQL("CREATE TABLE apps(pkg TEXT PRIMARY KEY, name TEXT)")
        db.execSQL("CREATE INDEX idx_s ON sessions(s)")
        db.execSQL("CREATE TABLE notifs(t INTEGER, pkg TEXT, PRIMARY KEY(t, pkg))")
    }
    override fun onUpgrade(db: SQLiteDatabase, o: Int, n: Int) {
        if (o < 2) db.execSQL("CREATE TABLE IF NOT EXISTS notifs(t INTEGER, pkg TEXT, PRIMARY KEY(t, pkg))")
    }
    fun saveNotif(t: Long, pkg: String) {
        val v = ContentValues().apply { put("t", t); put("pkg", pkg) }
        writableDatabase.insertWithOnConflict("notifs", null, v, SQLiteDatabase.CONFLICT_IGNORE)
    }
    fun notifsJson(from: Long, to: Long): JSONArray {
        val arr = JSONArray()
        readableDatabase.rawQuery(
            "SELECT n.t, n.pkg, IFNULL(a.name, n.pkg) FROM notifs n LEFT JOIN apps a ON a.pkg = n.pkg WHERE n.t >= ? AND n.t < ?",
            arrayOf(from.toString(), to.toString())
        ).use { c -> while (c.moveToNext()) arr.put(JSONObject().put("t", c.getLong(0)).put("p", c.getString(1)).put("n", c.getString(2))) }
        return arr
    }

    fun saveSession(s: Long, e: Long, pkg: String) {
        val v = ContentValues().apply { put("s", s); put("e", e); put("pkg", pkg) }
        writableDatabase.insertWithOnConflict("sessions", null, v, SQLiteDatabase.CONFLICT_REPLACE)
    }
    fun saveApp(pkg: String, name: String) {
        val v = ContentValues().apply { put("pkg", pkg); put("name", name) }
        writableDatabase.insertWithOnConflict("apps", null, v, SQLiteDatabase.CONFLICT_REPLACE)
    }
    fun sessionsJson(from: Long, to: Long): String {
        val arr = JSONArray()
        readableDatabase.rawQuery(
            "SELECT s.s, s.e, s.pkg, IFNULL(a.name, s.pkg) FROM sessions s LEFT JOIN apps a ON a.pkg = s.pkg " +
                "WHERE s.s >= ? AND s.s < ? ORDER BY s.s", arrayOf(from.toString(), to.toString())
        ).use { c ->
            while (c.moveToNext()) {
                arr.put(JSONObject().put("s", c.getLong(0)).put("e", c.getLong(1)).put("p", c.getString(2)).put("n", c.getString(3)))
            }
        }
        return arr.toString()
    }
}
