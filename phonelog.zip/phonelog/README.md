# ስልክ ዘጋቢ (PhoneLog)
APK ለማግኘት: ይህን ፎልደር GitHub repo ላይ ጫን (upload) → Actions → "Build APK" → Artifacts → PhoneLog-apk ያውርዱ።
ወይም Android Studio ላይ ክፈት → Build > Build APK.
ከጫኑ በኋላ: መተግበሪያውን ክፈት → «ፈቃድ ስጥ» → "ስልክ ዘጋቢ" አብራ።

## በ Chrome መክፈትና Install ማድረግ (PWA)
GitHub repo → Settings → Pages → Source: "GitHub Actions". ከዚያ የሚሰጥዎትን https አድራሻ Chrome ላይ ይክፈቱ → «⬇ Install» ወይም Chrome ሜኑ ⋮ → "Install app".
ማሳሰቢያ: በ Chrome የሚከፈተው ስሪት የስልክ አጠቃቀም ማንበብ አይችልም (የናሙና መረጃ ብቻ)። እውነተኛ ቀረጻ የሚሰራው በ APK ብቻ ነው።
